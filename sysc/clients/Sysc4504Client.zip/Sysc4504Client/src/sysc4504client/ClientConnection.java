/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sysc4504client;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.Iterator;

/**
 *
 * @author lenovo212
 */
public class ClientConnection {

    private ArrayList<ArrayList<ArrayList<String>>> data;

    public ClientConnection() {
        initData();
        

    }

    public void connect() throws Exception {
//        try {
//            // this will load the MySQL driver, each DB has its own driver
//            Class.forName("com.mysql.jdbc.Driver");
//            // setup the connection with the DB.
//            connect = DriverManager.getConnection("jdbc:mysql://www.adeeba.ca/sysc?user=sysc&password=syscpass");
//
//            // statements allow to issue SQL queries to the database
//            statement = connect.createStatement();
//            // resultSet gets the result of the SQL query
//            resultSet = statement.executeQuery("select * from courses");
//            writeResultSet(resultSet);
//
//        } catch (Exception e) {
//            throw e;
//        } finally {
//            close();
//        }

        //TODO establish a connection to the server
        // do sql query and get all the data
    }

    private void initData(){
        data = new ArrayList<ArrayList<ArrayList<String>>>();
        for (int i = 0; i < 4; i++) {    
            data.add(new ArrayList<ArrayList<String>>());
        }
    }
    public void sendPost(int standing) throws Exception {
                initData();
		String url = "http://www.adeeba.ca/sysc/shabka/server.php";
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
 
		//add reuqest header
		con.setRequestMethod("POST");
                //String USER_AGENT = null;
		//con.setRequestProperty("User-Agent", USER_AGENT);
		//con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
       		String urlParameters = "typeofrequest=getCourses&major=sysc";
                
		// Send post request
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(urlParameters);
		wr.flush();
		wr.close();
 
		int responseCode = con.getResponseCode();
		/*System.out.println("\nSending 'POST' request to URL : " + url);
		System.out.println("Post parameters : " + urlParameters);
		System.out.println("Respnose Code : " + responseCode);
 */
		BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
 
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
 
                String resString = response.toString();
		//print result
//		System.out.println(response.toString());
                
                String[] crses= resString.split("\"CRSE_ID\"");
                for (int i = 0; i < crses.length; i++) {
                  //  System.out.println(crses[i]);
                    int index = crses[i].indexOf(":\"");
                    int yearIndex=crses[i].indexOf("\"YEAR\":",index);
                    int termIndex=crses[i].indexOf("\"TERM\"");
                    
                   
                    ArrayList<String> temp = new ArrayList<String>();
                    if(index != -1){                       
                        String crseId = crses[i].substring(index+2,yearIndex-2);
                        int year = Integer.parseInt(crses[i].substring(yearIndex+8,yearIndex+9))-1;
                        String term = crses[i].substring(termIndex+8,termIndex+9);
                        if(standing-1 <= year){
                            temp.add(crseId);
                            temp.add(term);
                            data.get(year).add(temp);
                        }
                    }
                }
    }

    public TableModel getTableModel() {
        
        DefaultTableModel tm = new DefaultTableModel();
        // 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 
        int row[] = new int[8];
        for (int i = 0; i < row.length; i++) {
            row[i] = 1;
        }
        tm.setRowCount(20);
        tm.setColumnCount(8);
        String[] array = {"First","Year","Second","Year","Third","Year","Fourth","Year"};
        tm.setColumnIdentifiers(array);
        
        //Setting the headers
        for (int i = 0; i < 8; i+=2){
            tm.setValueAt("Fall", 0,i);
            tm.setValueAt("Winter", 0, i+1);
        }
        
        Iterator resultSet = data.iterator();
        @SuppressWarnings("UnusedAssignment")
        ArrayList coursesPerYear= new ArrayList<>();
        ArrayList courseData = new ArrayList<>();
        
        String course;
        String courseTitle;
        String courseTerm;
        int colIndex = 0;
        int rowIndex = 0;
        int counter = 0;
        while (resultSet.hasNext()) {
            coursesPerYear = (ArrayList) resultSet.next();
            Iterator courseInfo = coursesPerYear.iterator();
            while (courseInfo.hasNext()){
                colIndex = counter;
                courseData.add((ArrayList) courseInfo.next());
                course = courseData.get(0).toString().replace("[", "").replace("]", "");
                String [] crse_time = course.split(",");
                courseTitle = crse_time[0];
                courseTerm = crse_time[1].trim();
                //System.out.println("omar "+crse_time[0] + "\nomar 1 " + crse_time[1]+"\n");
               
               // System.out.println(courseTerm);
                if(courseTerm.equalsIgnoreCase("f")){
                   // System.out.println("1st if and colIndex = \n"+colIndex);
                    colIndex *= 2;
                    tm.setValueAt(courseTitle, row[colIndex], colIndex);
                    row[colIndex]++;
                }else if(courseTerm.equalsIgnoreCase("w")){
                    //System.out.println("2nd if\n");
                    //System.out.println("row :"+row[colIndex] + "column "+ colIndex + "\n");
                    colIndex = colIndex * 2 +1;
                   // System.out.println("colIndex"+colIndex + "row "+row[colIndex]);
                    tm.setValueAt(courseTitle, row[colIndex], colIndex);
                    row[colIndex]++;
                }else if(courseTerm.equalsIgnoreCase("fw") || courseTerm.equalsIgnoreCase("wf")){
                    //System.out.println("3rd if\n");
                    colIndex *= 2;
                    tm.setValueAt(courseTitle, row[colIndex], colIndex);
                    row[colIndex]++;
                    colIndex += 1;
                    tm.setValueAt(courseTitle, row[colIndex], colIndex);
                    row[colIndex]++;
                }else{
                    System.out.println("exception if\n");
                } 
                                
                courseData.clear(); 
            }
            counter++;
        }
    return tm;
}
}